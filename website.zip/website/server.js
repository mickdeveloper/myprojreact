const express=require("express")   //function
const app=express() //module
app.use(express.urlencoded({extended:false}))
const userRouter=require("./routers/user")
const adminRouter=require("./routers/admin")
const session=require('express-session')

const mongoose=require("mongoose") //
mongoose.connect('mongodb://127.0.0.1:27017/ravisir',()=>{console.log("connceted db")})

app.use(session({
    secret:'miki',
    saveUninitialized:false,
    resave:false
}))



app.use('/admin',adminRouter)
app.use(userRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000, ()=>{
    console.log("server is runing on port 5000")
})  
