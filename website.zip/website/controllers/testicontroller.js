const Testi=require('../models/testi')   //table called
const Contact=require('../models/contac')

exports.admintestishow=async(req,res)=>{
     const record=await Testi.find()
     
    res.render('admin/testi.ejs',{record})
}

exports.admintestidelete=async(req,res)=>{
    const id=req.params.id
    const record= await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testi')
}

exports.admintestistatus=async(req,res)=>{
    const id=req.params.id
    const record=await Testi.findById(id)
    let status=null
if(record.status=='unpublish'){
    status='publish'
}
    else{
        status='unpublish'
    }
    await Testi.findByIdAndUpdate(id,{status:status})
    res.redirect('/admin/testi')



}