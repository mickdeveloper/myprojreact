const services = require('../models/services')
const Services=require('../models/services')
const Contact=require('../models/contac')



exports.adminservicepagedisplay=async(req,res)=>{
    const record=await Services.find().sort({postDate:-1})
    const servicescount=await Services.count()
    
    const unpublishservice=await Services.count({status:'unpublish'})
    const publishservice=await Services.count({status:'publish'})
    
    res.render('admin/service.ejs',{record,servicescount,unpublishservice,publishservice})
}
exports.adminserviceform=(req,res)=>{
    res.render('admin/serviceform.ejs')

}
exports.adminserviceformrecord=async(req,res)=>{
    const filename=req.file.filename
    const currentdate= new Date()
    const {sname,sdesc,sldesc}= req.body
    
    const record= new Services({name:sname,desc:sdesc,ldsc:sldesc,img:filename,postDate:currentdate})
   await record.save()
//    console.log(record)
    res.redirect('/admin/services')

} 
exports.adminservicedelete=async(req,res)=>{
     const id=req.params.id
     const record=await Services.findByIdAndDelete(id)
     res.redirect('/admin/services')
}
exports.servicedeatilsrecord= async(req,res)=>{
    
    const id =req.params.id
    const record= await Services.findById(id)
    const contactrecord= await Contact.findOne()
    res.render('servicemore.ejs',{record,contactrecord}) 
    
}
exports.adminservicestatus=async(req,res)=>{
const id=req.params.id
const record= await Services.findById(id)
let status=null
if(record.status=='unpublish'){
    status='publish'
}
    else{
        status='unpublish'
    }
    await Services.findByIdAndUpdate(id,{status:status})
    res.redirect('/admin/services')

}


