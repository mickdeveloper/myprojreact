const Adminreg=require('../models/adminreg')



exports.adminlog=async(req,res)=>{
    // console.log(req.body)
    const{us,pass}=req.body
   const record= await Adminreg.findOne({username:us})
//    console.log(record)
   if(record!==null){
    if(record.password==pass){
        req.session.isAuth=true      //trigger for session
        res.redirect('/admin/dashboard')
    }else{
        res.redirect('/admin')   
    }
   }
   else{
    res.redirect('/admin')
   }

}
exports.showdashboard=(req,res)=>{
    res.render('admin/dashboard.ejs')
}
exports.adminlogout=(req,res)=>{
    req.session.destroy()                     // for logout
    res.redirect('/admin/')
}