const Contact=require('../models/contac')


exports.showcontact=async(req,res)=>{
    const record=await Contact.findOne()
   res.render('admin/contact.ejs',{record})
}
exports.updatecontact=async(req,res)=>{
    const id= req.params.id
     const record=await Contact.findById(id)
    res.render('admin/contactform.ejs',{record})
}
exports.contactrecordsupdate=async(req,res)=>{
    const id= req.params.id
    const {add,mob,phone,email}= req.body
    const record=await Contact.findByIdAndUpdate(id,{address:add,mob:mob,phone:phone,email:email})
    res.redirect('/admin/contact')

    
}