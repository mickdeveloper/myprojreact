const Banner=require('../models/banner') //table called 
const Contact=require('../models/contac')

exports.adminbannershow=async(req,res)=>{
    const record=await Banner.findOne()
    // console.log(record)
    res.render('admin/banner.ejs',{record})
}
exports.adminbannerupdate= async(req,res)=>{
    const id=req.params.id
    const record=await Banner.findById(id)
    res.render('admin/bannerupdate.ejs',{record})
}
exports.adminbannerupdatercord=async(req,res)=>{
    const {bt,bd,bdl}=req.body
    const id=req.params.id
    if(req.file){
        const filename= req.file.filename
        const record = await Banner.findByIdAndUpdate(id,{title:bt,desc:bd,ldesc:bdl,img:filename})
    }else{
        const record = await Banner.findByIdAndUpdate(id,{title:bt,desc:bd,ldesc:bdl})  
    }
   
    res.redirect('/admin/banner')
}

exports.bannershowmore=async(req,res)=>{
    const record= await Banner.findOne()
    const contactrecord= await Contact.findOne()
    res.render('bannermore.ejs',{record,contactrecord})
}