const mongoose=require('mongoose')


const servicesdata= mongoose.Schema({

    img:String,
    name:String,
    desc:String,
    ldsc:String,
    status:{type:String, default:'unpublish'},
    postDate:Date
})



module.exports=mongoose.model('service',servicesdata)