const mongoose=require('mongoose')

const banner=mongoose.Schema({
title:String,
desc:String,
ldesc:String,
img:String
})


module.exports= mongoose.model('banner',banner)