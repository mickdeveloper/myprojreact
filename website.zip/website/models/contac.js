const mongoose=require('mongoose')


const contactSchema=mongoose.Schema({
    address:String,
    mob:Number,
    email:String,
    phone:String
})


module.exports=mongoose.model('contact',contactSchema)