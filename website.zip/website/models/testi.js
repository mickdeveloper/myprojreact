const mongoose=require('mongoose')


const testidata=mongoose.Schema({
    img:String,
    cname:String,
    feedback:String,
    status:{type:String, default:'unpublish'},
    postDate:Date

})


module.exports=mongoose.model('testi',testidata)