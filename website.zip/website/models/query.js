
const mongoose=require('mongoose')


const querydata=mongoose.Schema({
    email:String,
    query:String,
    status:{type:String,default:'unread'}

})


module.exports=mongoose.model('query',querydata)