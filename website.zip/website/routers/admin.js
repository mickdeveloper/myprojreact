const router=require("express").Router()

//controller calling
const adminregc=require('../controllers/adminregcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicesc=require('../controllers/servicescontroller') 
const queryc= require("../controllers/querycontroller")
const testic= require('../controllers/testicontroller')
const contactc=require('../controllers/contactcontroller')
const multer=require('multer')
const { Query } = require("mongoose")

let storage=multer.diskStorage({
    destination: function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename: function(req,file,cb){
            cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1202*1}
})

function handlelogin(req,res,next){     //mid ware function for secure
    if(req.session.isAuth){
      next()
    }
    else{
        res.redirect('/admin/')

    }
}

router.get("/",(req,res)=>{
    res.render('admin/adminlogin.ejs')
})
router.post('/login',adminregc.adminlog)
router.get('/dashboard',handlelogin,adminregc.showdashboard)
router.get('/logout',adminregc.adminlogout)
router.get('/banner',bannerc.adminbannershow)
router.get('/bannerupdate/:id',bannerc.adminbannerupdate)
router.post('/bannerupdaterecord/:id',upload.single('img'),bannerc.adminbannerupdatercord)
router.get('/services',servicesc.adminservicepagedisplay)
router.get('/serviceadd',servicesc.adminserviceform)
router.post('/servicerecord',upload.single('img'),servicesc.adminserviceformrecord)
router.get('/servicedelete/:id',servicesc.adminservicedelete)
router.get('/servicestatusupdate/:id',servicesc.adminservicestatus)
router.get('/query',queryc.adminshowquery)
router.get('/testi',testic.admintestishow)
router.get('/testidelete/:id',testic.admintestidelete)
router.get('/testistatusupdate/:id',testic.admintestistatus)
router.get('/query',queryc.adminshowquery)
router.get('/queryreply/:id',queryc.adminqueryform)
router.post('/queryformreply/:id',upload.single('attachment'),queryc.adminquerysend)
router.get('/querydelete/:id',queryc.adminquerydelete)
router.post('/querysearch',queryc.adminquerysearch)
router.get('/contact',contactc.showcontact)
router.get('/updatecontact/:id',contactc.updatecontact)
router.post('/contactrecords/:id',contactc.contactrecordsupdate)
module.exports=router;