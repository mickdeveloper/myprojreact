const router=require("express").Router()
const Banner=require('../models/banner')
const Query=require('../models/query')
const Testi=require('../models/testi')

const Services=require('../models/services')
const bannerc=require('../controllers/bannercontroller')
const servicesc=require('../controllers/servicescontroller')
const queryc= require("../controllers/querycontroller")
const testic=require('../controllers/testicontroller')
const contactc=require('../controllers/contactcontroller')
const multer=require('multer')
const Contact=require('../models/contac')


let storage=multer.diskStorage({
    destination: function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename: function(req,file,cb){
            cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1202*1}
})


router.post('/queryrecords',async(req,res)=>{
    const {email,query}=req.body
    const record=new Query({query:query,email:email})
    await record.save()     
    // console.log(record) //for showing data save or not in  db
    res.redirect("/")
})

router.get('/testiformurl',async(req,res)=>{
    const contactrecord= await Contact.findOne()
    res.render('testiuser.ejs',{contactrecord})
})
router.post('/testirecords',upload.single('img'),async(req,res)=>{
    // console.log(req.body)
    // const filename=req.file.filename
    // const id = req.params.id
    const currentdate= new Date()
    const {cname,feedback}=req.body
   
    if(req.file){
        const filename= req.file.filename
        const record = await new Testi({cname:cname,feedback:feedback,postDate:currentdate,img:filename})
        await record.save()
    }else{
        const record = await  new Testi({cname:cname,feedback:feedback,postDate:currentdate})  
        await record.save()
    }
    // const record=new Testi({cname:cname,feedback:feedback,postDate:currentdate,img:filename})
    
    // console.log(record)
    res.redirect('/')


})


router.get("/",async(req,res)=>{
    const bannershowrrecord=await Banner.findOne()
    const serivecerecord=await Services.find({status:'publish'})
    const testiuserrecord=await Testi.find({status:'publish'})
    const contactrecord= await Contact.findOne()
    // console.log(testiuserrecord)
   res.render('index.ejs',{bannershowrrecord,serivecerecord,testiuserrecord,contactrecord})
})


// bannerc.bannershowcollection
router.get('/bannermore',bannerc.bannershowmore)



router.get('/sarvicedatils/:id',servicesc.servicedeatilsrecord)
module.exports=router;   //globle