const Testi=require('../models/testi')


let sess=null
exports.showtesti=(req,res)=>{
    //for username continue print 
   const username =req.session.username
   res.render('testi.ejs',{username})

}