const Reg=require('../models/reg')
const bcrypt=require('bcrypt')
const nodemailer=require('nodemailer')




exports.insertreg=async(req,res)=>{
      const{us,pass}=req.body 
      // here we checking username diffrent or not if user take same username by who already take firstly then we don't alow to another to take it. 
      const usercheck=await Reg.findOne({username:us})   
     //if console.log give value 'null', then the the data/value not taken yet by username.
    //    console.log(usercheck)
    const covertpass=await bcrypt.hash(pass,10)
     if(usercheck==null){
        const record=new Reg({username:us,password:covertpass})
        await record.save()
        //  console.log(record)
        // res.render('reg.ejs',{message:'your account has been created successfully'})
     }
     else{
        res.send(`${us}username already taken it,please take another!`)
     }
      //  console.log(record)
      res.send('account created succssfully.')
}
exports.login=(req,res)=>{
    res.render('login.ejs',{meassage:''})
}
// exports.logincheck=async(req,res)=>{
//     const {us,pass}=req.body   //sperate 
//     const record=await Reg.findOne({username:us}) //check
//     // console.log(record)
//     if(record!==null){
//         const comparepass=await bcrypt.compare(pass,record.password)
//         // console.log(comparepass)
//         if(comparepass){
//             req.session.isAuth=true
//             //we declred globle scope sess (where is value null) in frontend and here  we call us for print value 
//             sess=req.session
//             sess.username=us
//             //  console.log(sess.username)
//        res.redirect('/')
//         }
//         else{
//             // res.redirect('/login')
//             res.render('login.ejs',{meassage:' Opps! invalid username or password'})
//         }
//     }
// else{
//     // res.redirect('/login')
//     res.render('login.ejs',{meassage:' Opps! invalid username or password'})
// }
// }

exports.logout=(req,res)=>{
req.session.destroy()
res.redirect('/login')
}
exports.adminloginshow=(req,res)=>{
    res.render('admin/login.ejs')
}
exports.adminlogincheck=async(req,res)=>{
    const {us,pass}=req.body
    const record=await Reg.findOne({username:us})
    // console.log(record)
 if(record!==null){
    res.redirect('/admin/dashboard')
 }else{
    res.redirect('/admin/')
 }
}
exports.admindashboardshow=(req,res)=>{
    res.render('admin/dashboard.ejs')
}
exports.adminlogout=(req,res)=>{
   req.session.destroy()
   res.redirect('/admin/')
}
exports.adminusershow=async(req,res)=>{
   
   const record=await Reg.find().sort({createTime:-1})
   const totalUser= await Reg.count()
   const totalActive=await Reg.count({status:'active'})
   const totalSuspended=await Reg.count({status:'suspended'})
   res.render('admin/user.ejs',{record,totalUser,totalActive,totalSuspended})
}
exports.adminuserstatusupdate=async(req,res)=>{
const id=req.params.id
const record=await Reg.findById(id)
if(record.status=='suspended'){
   newstatus='active'
}
else{
   newstatus='suspended'
}
await Reg.findByIdAndUpdate(id,{status:newstatus})
res.redirect('/admin/users')
}

exports.adminrole=async(req,res)=>{
   // console.log(req.params.id)
   const id= req.params.id
   const record=await Reg.findById(id)
   // console.log(record)
   let newrole=null;
   if(record.role=='public'){
       newrole='pvt'
   }else{
      newrole='public'
   }
   await Reg.findByIdAndUpdate(id,{role:newrole})
   res.redirect('/admin/users')
}

exports.adminuserdelete=async(req,res)=>{
   const id=req.params.id
   await Reg.findByIdAndDelete(id)
   res.redirect('/admin/users')
}

exports.homepage=(req,res)=>{
   // console.log(req.session)
   const username=req.session.username
   res.render('index.ejs',{username})
}

exports.profile=async(req,res)=>{
   const username=req.session.username
   console.log(req.file)
   const record=await Reg.findOne({username:username})
   res.render('profile.ejs',{username,record})
}

exports.profilerecord=async(req,res)=>{
      //console.log(req.body)
       //console.log(req.session)
   const username=req.session.username
   //   console.log(username)
     const record=await Reg.findOne({username:username})
     //console.log(record)
    const filename=req.file.filename

   const {fname,lname,email,mobile,img}=req.body
  await Reg.findByIdAndUpdate(record.id,{firstName:fname,lastName:lname,email:email,
moblie:mobile,img:filename})
   res.redirect('/profile')
   }

   exports.passrestshow=(req,res)=>{
      const username=req.session.username
      res.render('passrest.ejs',{username})
   }

   exports.restpassrecord=async(req,res)=>{
      const {cpass,npass}=req.body
      const newpassword=await bcrypt.hash(npass,10)
      const username=req.session.username
      const record=await Reg.findOne({username:username})
      // console.log(record)
      const comparepass=await bcrypt.compare(cpass,record.password)
      // console.log(comparepass)
      if(comparepass){
         await Reg.findByIdAndUpdate(record.id,{password:newpassword})
         req.session.destroy()
         res.redirect('/login')
      }
      else{
         res.send('password incorrect')
      }
      }

      exports.forgot=(req,res)=>{
         res.render('forgot.ejs')
      }
      exports.forgotrecords=async(req,res)=>{
         const {us}=req.body
         const record=await Reg.findOne({username:us})
         console.log(record.email)
         // console.log(record)
         if(record.email!==''){
            //  const customeremail=record.email
            const coustmermail=record.email
            let testAccount = await nodemailer.createTestAccount();

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: 'sharewithcoder@gmail.com', // generated ethereal user
      pass: 'rsqcjwfseitoikpr', // generated ethereal password
    },
  });
  let info = await transporter.sendMail({
   from: 'sharewithcoder@gmail.com', // sender address
   to: "habibkhan190102@gmail.com", // list of receivers
   subject: "Change password ", // Subject line
   text: "Please change your password immediately from the Password tab in settings.your twitter account might be try to hacked. If you are logged out, go to Login and click on Forgot Password to reset your password. Please select a strong password you haven't used before. If you can't log in, your account may have been hacked.", // plain text body
   html: `<a href='http://localhost:5000/forgotuser/${us}'>click here to change</a>`, // html body
 });

  console.log('connected to smtp server')
         }
}
exports.forgotuser=(req,res)=>{
   const user=req.params.username
   res.render('forgotformlink.ejs',{user})
}

exports.newchangepass=async(req,res)=>{
   const user=req.params.user
   const record=await Reg.findOne({username:user})
   // console.log(record)
   // console.log(user)
   
   const {newpass}=req.body
   const convrtpass=await bcrypt.hash(newpass,10)
   await Reg.findByIdAndUpdate(record.id,{password:convrtpass})
   res.send('password was successfully changed.pls login refresh')
   res.redirect('/login')
}