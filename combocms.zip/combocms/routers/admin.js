const router=require('express').Router()
const regc=require('../controllers/regcontroller')
// const Reg=require('../models/reg')


router.get('/',regc.adminloginshow)
router.post('/loginrecord',regc.adminlogincheck)
router.get('/dashboard',regc.admindashboardshow)
router.get('/logout',regc.adminlogout)
router.get('/users',regc.adminusershow)
router.get('/userupdatestatus/:id',regc.adminuserstatusupdate)
router.get('/userrole/:id',regc.adminrole)
router.get('/userdelete/:id',regc.adminuserdelete)


module.exports=router;