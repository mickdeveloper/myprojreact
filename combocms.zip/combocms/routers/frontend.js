const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const testic=require('../controllers/testicontroller')
const Reg=require('../models/reg')
const bcrypt=require('bcrypt')
const multer = require('multer')


let sess=null;


function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }
    else{
      res.redirect('/login')
    }
}

function handlerole(req,res,next){
    if(req.session.role=='pvt'){
    next()
}else{
    res.send('to access continue subscribe us')
    res.redirect('/')
}
}

let storage=multer.diskStorage({
    destination:function(req,file,cb) {
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now +file.originalname)
    }
})
let upload=multer({
    storage:storage,
    limits:{fieldSize:1024*1024*5}

})


router.get('/',handlelogin,regc.homepage)

router.get('/reg',(req,res)=>{
    // console.log(sess.username)
   
    res.render('reg.ejs')
    // res.render('reg.ejs',{message:''})

})
router.post('/regrecords',regc.insertreg)
router.get('/login',regc.login)

router.post('/loginrecords',async(req,res)=>{
    const {us,pass}=req.body   //sperate 
    const record=await Reg.findOne({username:us}) //check
    // console.log(record)
    if(record.status=='active'){
    if(record!==null){
        const comparepass=await bcrypt.compare(pass,record.password)
        // console.log(comparepass)
        if(comparepass){
            req.session.isAuth=true
            //we declred globle scope sess (where is value null) in frontend and here  we call us for print value 

            sess=req.session
            sess.username=us
            sess.role=record.role
            //  console.log(sess.username)
       res.redirect('/')
        }
        else{
            res.redirect('/login')
            // res.render('login.ejs',{meassage:' Opps! invalid username or password'})
        }
    }

else{
    res.redirect('/login')
    // res.render('login.ejs',{meassage:' Opps! invalid username or password'})
}
    }else{
        res.send('your ac has been temprary suspended.')
    }
})
router.get('/logout',regc.logout)

router.get('/testi',handlelogin,handlerole,testic.showtesti)
router.get('/profile',handlelogin,regc.profile)
router.post('/profilerecord',handlelogin,upload.single('img'),regc.profilerecord)
router.get('/passrest',regc.passrestshow)
router.post('/restrecord',regc.restpassrecord)
router.get('/forgot',regc.forgot)
router.post('/forgotrecords',regc.forgotrecords)
router.get('/forgotuser/:username',regc.forgotuser)
router.post('/newpass/:user',regc.newchangepass)


module.exports=router;