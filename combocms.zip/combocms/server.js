const express=require('express')
const app=express()
app.use(express.urlencoded({extended:false}))
const adminRouter=require('./routers/admin')
const forntRouter=require('./routers/frontend')

require('dotenv').config()   // configeation of dotenv file
const session=require('express-session')
const mongoose=require('mongoose')
mongoose.connect(process.env.DB_URl+'/'+process.env.DB_NAME)

app.use(session({
    secret:'mimi',
    saveUninitialized:false,
    resave:false,
    cookie:{maxAge:1000*60*60*24*365}
    
})
)
app.use('/admin',adminRouter)
app.use(forntRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{
    console.log(`server is runnig on port ${process.env.PORT}`)
})