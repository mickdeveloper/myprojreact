const mongoose=require('mongoose')
// let fullDate=new Date()
// let newDate=fullDate.setFullYear()


const regSchema=mongoose.Schema({
    username:String,
    password:String,
    dob:String,
    firstName:String,
    lastName:String,
    email:String,
    moblie:String,
    img:String,
    createTime:{type:String,default: new Date()},
    status:{type:String, default:'suspended'},
    role:{type:String, default:'public'}
})

module.exports=mongoose.model('reg',regSchema)